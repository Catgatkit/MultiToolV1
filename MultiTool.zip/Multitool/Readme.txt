Thank you for downloading Multitool from Unknown 

So if you want to change the color of the MultiTool you can go ahead and edit it and there is Color d by default so change that to color a for example and you get a green ui

Requirements:
Must have firefox installed for youtube and twitch to work

Must have Steam and Discord installed 

Go check my github for possible updates